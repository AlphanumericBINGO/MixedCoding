import string

LOWER = string.ascii_lowercase
UPPER = string.ascii_uppercase

def atbash(text: str) -> str:
    '''
    Docstring for atbash
    
    :param text: Description
    :type text: str
    :return: Description
    :rtype: str
    '''
    result = []
    for char in text:
        if char in LOWER:
            result.append(LOWER[::-1][LOWER.index(char)])
        elif char in UPPER:
            result.append(UPPER[::-1][UPPER.index(char)])
        else:
            result.append(char)
    return ''.join(result)
