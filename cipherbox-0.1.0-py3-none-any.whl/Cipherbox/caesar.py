import string

LOWER = string.ascii_lowercase
UPPER = string.ascii_uppercase

def encode(text: str, shift: int) -> str:
    '''
    Docstring for encode
    
    :param text: Description
    :type text: str
    :param shift: Description
    :type shift: int
    :return: Description
    :rtype: str
    '''
    result = []
    for char in text:
        if char in LOWER:
            result.append(LOWER[(LOWER.index(char) + shift) % 26])
        elif char in UPPER:
            result.append(UPPER[(UPPER.index(char) + shift) % 26])
        else:
            result.append(char)
    return ''.join(result)

def decode(text: str, shift: int) -> str:
    return encode(text, -shift)
