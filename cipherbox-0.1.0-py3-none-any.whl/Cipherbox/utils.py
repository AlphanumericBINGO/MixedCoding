import string

def clean(text: str) -> str:
    '''
    Docstring for clean
    
    :param text: Description
    :type text: str
    :return: Description
    :rtype: str
    '''
    return ''.join(c for c in text if c not in string.punctuation)

def normalize(text: str) -> str:
    '''
    Docstring for normalize
    
    :param text: Description
    :type text: str
    :return: Description
    :rtype: str
    '''
    return text.lower().strip()
