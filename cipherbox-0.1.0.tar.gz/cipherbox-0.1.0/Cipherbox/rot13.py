from .caesar import encode

def rot13(input: str) -> str:
    '''
    Docstring for rot13
    
    :param input: str
    :type input: str
    :return: Description
    :rtype: str
    '''
    return encode(input, shift=13)
